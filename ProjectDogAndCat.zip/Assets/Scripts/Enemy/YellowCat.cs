using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class YellowCat : MonoBehaviour
{

    public float speed;
    public Rigidbody2D target;

    bool isLive;
    Rigidbody2D rigid;

    private void Awake()
    {
        
      rigid = GetComponent<Rigidbody2D>();




    }




    private void FixedUpdate()
    {
        
    }













}
