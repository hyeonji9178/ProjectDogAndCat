using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStart : MonoBehaviour
{
    public GameObject Gamestart;
    public GameObject IntroMenu;


    public void OnCilckGameStart()
    {
        Gamestart.SetActive(true);
        IntroMenu.SetActive(false);






    }



















}
